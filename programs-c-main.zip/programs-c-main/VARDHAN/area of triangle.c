//print area of triangle 
#include<stdio.h>
void main(){
	float h,b,a;
	printf("ENTER VALUE OF HEIGHT\n");
	scanf("%f",&h);
	printf("ENTER VALUE OF BASE\n");
	scanf("%f",&b);
	a=(h*b)/2;
	printf("%f",a);
	

}
