//PRINT ADDRESS
#include<stdio.h>
void main(){
	printf("401 Radhekrishna palace,\n9 Diwanpara Palace Road,\nRajkot.");
}
