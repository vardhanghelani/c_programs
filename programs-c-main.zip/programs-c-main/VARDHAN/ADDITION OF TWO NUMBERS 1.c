//PRINT ADDITION OF TWO NUMBERS(WITHOUT SCANF)
#include <stdio.h>
void main(){
	int a=5,b=10,c;
	c=a+b;
	printf("%d",c);
}
