//print addition of 2 numbers(with scanf)
#include<stdio.h> 
void main(){
	int a,b,c;
	printf("value of A\n");
	scanf("%d",&a);
	printf("value of B\n");
	scanf("%d",&b);
	c=a+b;
	printf("value of c=%d",c);
}
