//print average of 3 num with scanf
#include<stdio.h>
void main(){
	int a,b,c;
	float avg;
	printf("ENTER VALUE OF A\n");
	scanf("%d",&a);
	printf("ENTER VALUE OF B\n");
	scanf("%d",&b);
	printf("ENTER VALUE OF C\n");
	scanf("%d",&c);
	avg=(a+b+c)/3.0;
	printf("%f",avg);
}
