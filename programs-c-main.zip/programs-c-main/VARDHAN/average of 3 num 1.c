//average of 3 numbers
#include<stdio.h>
void main(){
	int a=10,b=20,c=30;
	float avg;
	avg=(a+b+c)/3;
	printf("%f",avg);
}
