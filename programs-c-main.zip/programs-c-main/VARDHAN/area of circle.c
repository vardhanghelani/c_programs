//area of circle 
#include<stdio.h>
void main(){
	float r,a;
	printf("ENTER VALUE OF R\n");
	scanf("%f",&r);
	a=(22/7.0)*r*r;
	printf("%f",a);
}
